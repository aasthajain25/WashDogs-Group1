package com.webpages;

public class webpage {

	int x;
}
